---
name: agent-orchestrator
description: "Detailed team composition patterns and orchestration workflows for parallel agent execution. Complements agents-and-parallel.md rules (always loaded) with specific team patterns, decision trees, and phase-by-phase workflows. This skill should be used when: (1) planning team composition for a complex multi-task implementation, (2) choosing between TeamCreate vs parallel Agent tool, (3) setting up wave-based execution with dependencies, (4) needing the decision tree for selecting a team pattern. NOT needed for basic parallel execution already covered by rules."
---

# Agent Orchestrator

## Overview

Detailed reference for agent team orchestration patterns. Core rules (team mandatory, compacting resilience, mutual review) are enforced by `agents-and-parallel.md` (always loaded). This skill provides the detailed HOW: team patterns, decision trees, phase workflows, and selection criteria.

## When to Load This Skill

Load when detailed orchestration guidance is needed beyond the always-active rules:

- Planning team composition for a new implementation
- Choosing the right team pattern for a specific task type
- Setting up wave-based execution with complex dependencies
- Need the TeamCreate vs parallel Agent decision matrix

Do NOT load for basic parallel execution — the rules file handles that.

## Phase 1: Plan Analysis → Team Mapping

Before spawning any agents, analyze the plan to determine team composition.

### Decision Process

```
Read the plan (Plans.md or stated tasks)
  ↓
Identify independent task groups (can run in parallel)
  ↓
Identify dependencies (must run sequentially)
  ↓
Select team pattern from references/team-patterns.md
  ↓
Map each task group to an agent role
  ↓
Output Team Plan (required by rules)
```

## Phase 2: Team Creation Method Selection

### TeamCreate vs Parallel Agent Tool

| Condition | TeamCreate | Parallel Agents |
|-----------|-----------|-----------------|
| 2+ waves with dependencies | Yes | No |
| Need mutual review between workers | Yes | No |
| Independent one-shot tasks | No | Yes |
| Long-running (likely compacting) | Yes (more resilient) | Risky |
| 3+ agents needing coordination | Yes | Possible |

### TeamCreate Workflow

```
TeamCreate(team_name, description)
  ↓
TaskCreate (all tasks with descriptions)
  ↓
Agent (spawn teammates with team_name)
  ↓
TaskUpdate (assign tasks to teammates)
  ↓
Monitor via messages + TaskList
```

### Parallel Agent Workflow

```
Agent(task-A, run_in_background) +
Agent(task-B, run_in_background) +
Agent(task-C, run_in_background)
  [all in single message]
  ↓
Wait for completions
  ↓
Agent(code-reviewer, review all changes)
```

## Phase 3: Execution Monitoring

Track agent status and report at milestones:

```
┌──────────┬─────────┬────────┐
│ Agent    │ Task    │ Status │
├──────────┼─────────┼────────┤
│ name     │ task    │ status │
└──────────┴─────────┴────────┘
```

### Wave Transition

```
Wave N: All implementers complete
  ↓
Reviewer(s) cross-review all Wave N changes
  ↓
Fix any CRITICAL/HIGH issues
  ↓
Re-review if fixes were needed
  ↓
Wave N+1: Launch next set of agents
```

## Phase 4: Review Protocol

### Cross-Review Matrix

| Scenario | Reviewer |
|----------|---------|
| Agent A implements X | Agent B or dedicated reviewer |
| Agent B implements Y | Agent A or dedicated reviewer |
| Single implementer | Dedicated code-reviewer required |

### Review Checklist

- Code quality (naming, structure, readability)
- No mutations (immutable patterns)
- Error handling present
- No security vulnerabilities (OWASP top 10)
- Consistent with existing codebase patterns
- Tests cover the implementation

### Escalation

CRITICAL issues → Implementer fixes → Re-review → CRITICAL = 0 to proceed.

## Team Patterns Reference

See `references/team-patterns.md` for detailed patterns with role tables and task flows:

1. **Feature Implementation** — Wave-based multi-component features
2. **Bug Fix + Audit** — Fix + codebase-wide pattern search
3. **Refactoring** — Large-scale file modifications across many files
4. **Research + Implement** — Explore then build
5. **Lightweight Parallel** — Independent small tasks with haiku agents

Decision tree for pattern selection is also in `references/team-patterns.md`.
